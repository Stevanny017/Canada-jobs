# Canada Jobs Website

## Publish it for free with GitHub Pages
1. Create a GitHub account.
2. Create a new public repository.
3. Upload `index.html`.
4. In the repository, open Settings → Pages.
5. Select the `main` branch and root folder, then save.
6. GitHub will provide your website address.

The APPLY NOW button already points to the Google Form supplied for this project.

Before publishing, verify all recruitment, employer, LMIA and fee-related claims. Do not ask applicants for unnecessary sensitive information.
